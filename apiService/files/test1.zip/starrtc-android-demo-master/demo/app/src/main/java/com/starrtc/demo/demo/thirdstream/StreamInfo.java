package com.starrtc.demo.demo.thirdstream;

/**
 * Created by zhangjt on 2017/9/14.
 */

public class StreamInfo {
    public String creator;
    public String name;
    public String channelID;
    public String chatroomID;
    public String liveId;
    public String isLiveOn;
    public String url;
    public String streamType;
    public int listType;
}
