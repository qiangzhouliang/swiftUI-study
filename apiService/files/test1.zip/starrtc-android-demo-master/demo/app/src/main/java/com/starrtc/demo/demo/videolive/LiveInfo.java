package com.starrtc.demo.demo.videolive;

/**
 * Created by zhangjt on 2017/9/14.
 */

public class LiveInfo {
    public String createrId;
    public String liveName;
    public String liveId;
    public String isLiveOn;
}
