package com.starrtc.demo.demo.im.group;

/**
 * Created by zhangjt on 2017/9/14.
 */

public class MessageGroupInfo {
    public String groupName;
    public String createrId;
    public String groupId;
}
