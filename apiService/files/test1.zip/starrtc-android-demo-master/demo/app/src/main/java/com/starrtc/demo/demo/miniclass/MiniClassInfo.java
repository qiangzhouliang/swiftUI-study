package com.starrtc.demo.demo.miniclass;

/**
 * Created by zhangjt on 2017/9/14.
 */

public class MiniClassInfo {
    public String name;
    public String creator;
    public String id;
}
