package com.starrtc.demo.demo.im.chatroom;

/**
 * Created by zhangjt on 2017/9/14.
 */

public class ChatroomInfo {
    public String roomName;
    public String createrId;
    public String roomId;
}
