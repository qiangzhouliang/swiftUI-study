package com.starrtc.demo.demo.audiolive;

/**
 * Created by zhangjt on 2017/9/14.
 */

public class AudioLiveInfo {
    public String creator;
    public String name;
    public String id;
    public String isLiveOn;
}
