package com.starrtc.demo.demo.videomeeting;

/**
 * Created by zhangjt on 2017/9/14.
 */

public class MeetingInfo {
    public String meetingName;
    public String createrId;
    public String meetingId;
}
